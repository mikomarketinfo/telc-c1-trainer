/**
 * ==========================================================
 * TELC C1 Engine
 * Application Entry Point
 * ==========================================================
 */

import {CONFIG} from "./config.js";

import {$,debug} from "./utils/helpers.js";

window.addEventListener(

    "DOMContentLoaded",

    init

);

function init(){

    showVersion();

    debug("Application started.");

    debug(CONFIG);

}

function showVersion(){

    const version=$("version");

    if(version){

        version.textContent=

            CONFIG.VERSION;

    }

}